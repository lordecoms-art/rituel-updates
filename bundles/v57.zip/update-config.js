window.RITUEL_UPDATE_BASE='https://lordecoms-art.github.io/rituel-updates/';
