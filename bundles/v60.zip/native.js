/* ============================================================
   Rituel — pont natif (Capacitor)
   Chargé AVANT le script de l'app. Sur le web, il ne fait rien :
   l'app garde son comportement actuel.
   ============================================================ */
(function () {
  const C = window.Capacitor;
  const native = !!(C && C.isNativePlatform && C.isNativePlatform());
  window.RituelNative = { available: native };
  if (!native) return;

  const P  = () => C.Plugins.Preferences;
  const LN = () => C.Plugins.LocalNotifications;
  const AppPlugin = () => C.Plugins.App;

  /* ---------- 1. Stockage système ----------
     L'app cherche window.storage avec get/set. On lui donne
     Preferences, qui écrit dans les réglages natifs de l'app :
     pas de purge par le navigateur, sauvegardé avec l'appareil. */
  window.storage = {
    async get(key) {
      const { value } = await P().get({ key });
      return value == null ? null : { key, value };
    },
    async set(key, value) {
      await P().set({ key, value });
      return { key, value };
    },
    async delete(key) { await P().remove({ key }); return { key, deleted: true }; },
    async list() { const { keys } = await P().keys(); return { keys }; }
  };

  /* ---------- 2. Notifications locales ----------
     Contrairement au web, iOS déclenche celles-ci même app fermée
     et téléphone verrouillé : c'est tout l'intérêt du passage natif. */
  const PHRASES = [
    'Deux minutes maintenant valent mieux qu\u2019un rattrapage demain.',
    'Tu es à un geste de la valider.',
    'Celle-ci fait partie de ta journée.',
    'Un petit geste, et c\u2019est tenu.'
  ];
  const dkey = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const toMin = t => { const [a, b] = t.split(':').map(Number); return a * 60 + b; };

  /* nombre de validations du jour, occurrences multi-créneaux comprises */
  function doneToday(state, h, d) {
    const log = (state.log || {})[dkey(d)] || {};
    const ms = h.moments || [h.moment];
    if (h.type === 'weekly') {
      const mon = new Date(d); mon.setDate(d.getDate() - ((d.getDay() + 6) % 7));
      let s = 0;
      for (let i = 0; i < 7; i++) {
        const x = new Date(mon); x.setDate(mon.getDate() + i);
        s += ((state.log || {})[dkey(x)] || {})[h.id] || 0;
      }
      return s;
    }
    if (ms.length > 1) return ms.reduce((s, k) => s + (log[h.id + '#' + k] ? 1 : 0), 0);
    return log[h.id] || 0;
  }

  let syncing = false;
  async function syncAlerts(state) {
    if (syncing) return; syncing = true;
    try {
      let perm = await LN().checkPermissions();
      if (perm.display !== 'granted') {
        perm = await LN().requestPermissions();
        if (perm.display !== 'granted') return;
      }
      const pending = await LN().getPending();
      if (pending.notifications.length) await LN().cancel(pending);

      const habits = (state.habits || []).filter(h => !h.paused && h.alerts && h.alerts.on && (h.alerts.times || []).length);
      if (!habits.length) return;

      /* iOS plafonne à 64 notifications en attente.
         On programme des dates concrètes sur les prochains jours,
         ce qui permet de sauter celles déjà validées. */
      const slots = habits.reduce((s, h) => s + h.alerts.times.length, 0);
      const horizon = Math.max(1, Math.min(7, Math.floor(52 / Math.max(1, slots))));

      const now = new Date(), out = [];
      let id = 1;
      for (let dayOffset = 0; dayOffset < horizon; dayOffset++) {
        const day = new Date(now); day.setDate(now.getDate() + dayOffset); day.setHours(0, 0, 0, 0);
        const dow = (day.getDay() + 6) % 7;                       // 0 = lundi
        if ((state.off || {})[dkey(day)]) continue;               // journée neutre
        habits.forEach(h => {
          const a = h.alerts;
          if (!a.days || !a.days[dow]) return;
          if ((state.skip || {})[dkey(day)] && (state.skip || {})[dkey(day)][h.id]) return;
          const target = h.type === 'weekly' ? h.target : h.target;
          const already = dayOffset === 0 ? doneToday(state, h, now) >= target : false;
          if (already) return;                                    // déjà fait aujourd'hui : on n'en parle plus
          a.times.forEach(t => {
            const [hh, mm] = t.split(':').map(Number);
            const at = new Date(day); at.setHours(hh, mm, 0, 0);
            if (at <= now) return;
            out.push({
              id: id++,
              title: h.icon + '  ' + h.name,
              body: PHRASES[id % PHRASES.length],
              schedule: { at, allowWhileIdle: true },
              extra: { habitId: h.id }
            });
            /* relances : uniquement pour aujourd'hui, elles seront
               reprogrammées au prochain enregistrement */
            if (dayOffset === 0 && a.relance > 0) {
              for (let k = 1; k <= (a.max || 1); k++) {
                const r = new Date(at.getTime() + k * a.relance * 60000);
                if (r <= now) continue;
                out.push({
                  id: id++,
                  title: '↻ ' + h.icon + '  ' + h.name,
                  body: 'Toujours en attente.',
                  schedule: { at: r, allowWhileIdle: true },
                  extra: { habitId: h.id }
                });
              }
            }
          });
        });
      }
      if (out.length) await LN().schedule({ notifications: out.slice(0, 60) });
      window.RituelNative.scheduled = Math.min(out.length, 60);
    } catch (e) {
      console.warn('[Rituel] programmation des rappels impossible :', e);
    } finally { syncing = false; }
  }

  /* ---------- 3. Santé : pas du jour ----------
     Plugin capacitor-health (compatible Capacitor 7), enregistré sous HealthPlugin.
     Lecture directe de HealthKit : total des pas depuis minuit. */
  const HP = () => C.Plugins.HealthPlugin;
  let healthAsked = false;
  async function readSteps() {
    const hp = HP();
    if (!hp) return null;                                   /* plugin absent : on n'insiste pas */
    try {
      const av = await hp.isHealthAvailable();
      if (av && av.available === false) return null;
      if (!healthAsked) {
        await hp.requestHealthPermissions({ permissions: ['READ_STEPS'] });
        healthAsked = true;
      }
      const start = new Date(); start.setHours(0, 0, 0, 0);
      const end = new Date();
      const res = await hp.queryAggregated({
        startDate: start.toISOString(),                     /* ISO avec millisecondes, exigé par iOS */
        endDate: end.toISOString(),
        dataType: 'steps',
        bucket: 'day'
      });
      const rows = (res && res.aggregatedData) || [];
      return Math.round(rows.reduce((s, x) => s + (Number(x.value) || 0), 0));
    } catch (e) {
      console.warn('[Rituel] lecture des pas impossible :', e);
      return null;
    }
  }
  window.RituelNative.healthPlugin = () => !!HP();
  async function pullSteps() {
    const v = await readSteps();
    if (v != null && typeof window.applySteps === 'function') window.applySteps(v);
    return v;
  }

  /* ---------- 4. Retours haptiques (Taptic Engine) ---------- */
  const HAP = () => C.Plugins.Haptics;
  const wait = ms => new Promise(r => setTimeout(r, ms));
  async function haptic(kind) {
    const h = HAP(); if (!h) return;
    try {
      switch (kind) {
        case 'tap':     await h.impact({ style: 'LIGHT' }); break;
        case 'done':    await h.impact({ style: 'MEDIUM' }); break;
        case 'section': await h.impact({ style: 'MEDIUM' }); await wait(90); await h.impact({ style: 'LIGHT' }); break;
        case 'perfect': await h.notification({ type: 'SUCCESS' }); await wait(160); await h.impact({ style: 'HEAVY' }); break;
        case 'week':    await h.notification({ type: 'SUCCESS' }); await wait(140); await h.notification({ type: 'SUCCESS' }); break;
        case 'press':   await h.impact({ style: 'MEDIUM' }); break;
        case 'move':    await h.selectionChanged(); break;
        case 'warn':    await h.notification({ type: 'WARNING' }); break;
        default:        await h.impact({ style: 'LIGHT' });
      }
    } catch (e) { /* pas de moteur haptique : silence */ }
  }
  window.RituelNative.haptic = haptic;

  /* ---------- 5. Widget : résumé partagé + validations en retour ---------- */
  const WB = () => C.Plugins.WidgetsBridgePlugin;
  const GROUP = 'group.com.nicolas.rituel2026';
  let lastWidgetJSON = '';
  async function syncWidget(payload) {
    const wb = WB(); if (!wb || !payload) return;
    const json = JSON.stringify(payload);
    if (json === lastWidgetJSON) return;
    lastWidgetJSON = json;
    try { await wb.setItem({ key: 'rituel_widget', value: json, group: GROUP }); await wb.reloadAllTimelines(); }
    catch (e) { console.warn('[Rituel] widget :', e); }
  }
  async function pullPending() {
    const wb = WB(); if (!wb) return;
    try {
      const r = await wb.getItem({ key: 'rituel_pending', group: GROUP });
      const v = r && r.results;
      if (v) {
        const arr = JSON.parse(v);
        await wb.removeItem({ key: 'rituel_pending', group: GROUP });
        if (arr.length && window.applyWidgetPending) window.applyWidgetPending(arr);
      }
    } catch (e) { /* rien en attente */ }
  }
  /* ---------- 6. Live Activity : la carte de l'écran verrouillé ---------- */
  const LIVE = () => C.Plugins.RituelLive;
  let lastLiveJSON = '';
  async function syncLive(st) {
    const lp = LIVE(); if (!lp) return;
    try {
      if (!st) { if (lastLiveJSON) { lastLiveJSON = ''; await lp.end(); } return; }
      const json = JSON.stringify(st);
      if (json === lastLiveJSON) return;
      lastLiveJSON = json;
      await lp.update({ json });
    } catch (e) { console.warn('[Rituel] carte :', e); }
  }
  window.RituelNative.syncLive = syncLive;
  window.RituelNative.syncWidget = syncWidget;
  window.RituelNative.pullPending = pullPending;

  window.RituelNative.syncAlerts = syncAlerts;
  window.RituelNative.pullSteps  = pullSteps;
  window.RituelNative.readSteps  = readSteps;


  /* ---------- 7. Mises à jour à distance ----------
     L'app regarde latest.json sur GitHub Pages. Si une version plus récente existe,
     elle la télécharge et l'applique aussitôt (ou à la prochaine ouverture si tu es en train d'écrire).
     Si une version plante au démarrage, le plugin revient seul à la précédente. */
  const UPD = () => C.Plugins.CapacitorUpdater;
  let updChecking = false;
  async function checkUpdate() {
    const U = UPD(), base = window.RITUEL_UPDATE_BASE;
    const st = m => { window.RituelNative.updStatus = m; };
    if (!U) { st('plugin absent'); return; }
    if (!base) { st('adresse absente'); return; }
    if (updChecking) return;
    updChecking = true; st('vérification…');
    try {
      const r = await fetch(base + 'latest.json?t=' + Date.now(), { cache: 'no-store' });
      if (!r.ok) { st('GitHub ' + r.status); return; }
      const j = await r.json();
      const here = window.APP_VERSION || '';
      if (!j.version || j.version === here) { st('à jour (' + (j.version || '?') + ' en ligne)'); return; }
      const info = await AppPlugin().getInfo().catch(() => ({ build: '1' }));
      if (j.minBuild && Number(info.build || 1) < Number(j.minBuild)) { st(j.version + ' demande Xcode'); return; }   /* il faut une nouvelle compilation Xcode */
      const list = await U.list().catch(() => ({ bundles: [] }));
      let b = (list.bundles || []).find(x => x.version === j.version && x.status !== 'error');
      st('téléchargement ' + j.version + '…');
      if (!b) b = await U.download({ url: j.url, version: j.version });
      st(j.version + ' prête');
      window.RituelNative.pendingUpdate = j.version;
      /* en train d'écrire ou une fenêtre ouverte : on attend la prochaine ouverture */
      const ae = document.activeElement;
      const busy = document.querySelector('.sheet.open') || (ae && /INPUT|TEXTAREA|SELECT/.test(ae.tagName));
      if (busy) { await U.next({ id: b.id }); return; }
      /* sinon on l'applique tout de suite : on enregistre, on prévient, on recharge */
      try { if (typeof window.toast === 'function') window.toast('Mise à jour ' + j.version + '…'); } catch (e) {}
      try { if (typeof window.flushSave === 'function') await window.flushSave(); } catch (e) {}
      await new Promise(res => setTimeout(res, 700));
      await U.set({ id: b.id });
    } catch (e) { st('erreur : ' + ((e && (e.message || e.errorMessage)) || e)); console.warn('[Rituel] mise à jour :', e); }
    finally { updChecking = false; }
  }
  window.RituelNative.checkUpdate = checkUpdate;
  /* cette version a bien démarré : on la valide, sinon retour arrière automatique */
  try { UPD() && UPD().notifyAppReady(); } catch (e) {}

  /* ---------- 4. Cycle de vie ---------- */
  document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => { pullSteps(); pullPending(); }, 1200);
    setTimeout(() => { checkUpdate(); }, 1500);
  });
  try {
    AppPlugin().addListener('appStateChange', ({ isActive }) => {
      if (isActive) { pullSteps(); pullPending(); checkUpdate(); }
    });
    LN().addListener('localNotificationActionPerformed', () => {
      /* ouverture depuis une notification : on rafraîchit l'affichage */
      if (typeof window.render === 'function') window.render();
    });
  } catch (e) { /* plugins absents : on continue sans */ }
})();
